﻿# RPG Dungeon Crawler v3.1.0-beta

## Installation

1. Extract this ZIP to any folder
2. Make sure you have .NET 10 Runtime installed
3. Run Night.exe

## What's New

This version includes the Enhanced Combat System with 16 unique abilities!

- Use A1, A2, A3, A4 in combat to use abilities
- Manage Mana/Stamina resources
- Experience strategic combat with cooldowns

## Requirements

- Windows 10/11
- .NET 10 Runtime: https://dotnet.microsoft.com/download/dotnet/10.0

## Feedback

Report issues at: https://github.com/Yogi1972/Rpg_Dungeon/issues

Enjoy!
